﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CurdOperation.Model;

using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CurdOperation.DBContexts
{
    public class UserContext : DbContext
    {
        public UserContext(DbContextOptions<UserContext> options) : base(options)        
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            //modelBuilder.Entity<UserInformation>()
            //    .HasIndex(user => user.UserName).IsUnique()
            //    .HasKey(user => user.UserID).HasName("PrimaryKey_UserID");
            //modelBuilder.Entity<UserInformation>()
            //    .HasIndex(user => user.UserName).IsUnique();
            //    
            //modelBuilder.Entity<UserInformation>()
            //    .HasIndex(user => user.UserName).IsUnique(true);

            //modelBuilder.Entity<UserInformation>()
            //    .HasAlternateKey(user => user.UserName)
            //    .HasD("UX_IDTypes_Code")
            //    .IsUnique();

            //modelBuilder.Entity<UserInformation>()
            //.HasIndex(b => b.UserName)
            //.IsUnique();
        }



        public DbSet<UserInformation> Users { get; set;}

    }
}
