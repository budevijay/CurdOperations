﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CurdOperation.DBContexts;
using CurdOperation.Model;
using CurdOperation.Repository;
using System.Transactions;

namespace CurdOperation.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userRepository1;




        public UserController(IUserRepository userRepository)
        {
            _userRepository1 = userRepository;
        }


        [HttpGet]
        public IActionResult GetUsers()
        {
            var users = _userRepository1.GetUserInformation().ToList();
            if (users != null)
            {
                return new OkObjectResult(users);
            }
            else
            {
                return new NoContentResult();
            }
        }

        [HttpGet("{id}", Name = "GetUserById")]
        public IActionResult GetUserById(int id)
        {
            var users = _userRepository1.GetUserByID(id);
            if (users != null)
            {
                return new OkObjectResult(users);
            }
            else
            {
                return new NoContentResult();
            }
        }

        [HttpPost]
        public IActionResult InsertUser(string userName)
        {
            try
            {
                using (var scope = new TransactionScope())
                {
                    var user = _userRepository1.InsertUser(userName);
                    scope.Complete();
                    if (user != null)
                    {
                        return CreatedAtAction(nameof(GetUserById), new { id = user.UserID }, user);
                    }
                    else
                    {
                        return new NoContentResult();
                    }
                }
            }
            catch (Exception)
            {
                return new NoContentResult();
            }
        }

        [HttpPut]
        public IActionResult UpdateUser(int userId,string userName)
        {
            if (userId.ToString() != null)
            {
                using (var scope = new TransactionScope())
                {
                    _userRepository1.UpdateUser(userId, userName);
                    scope.Complete();
                    return new OkResult();
                }
            }
            return new NoContentResult();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _userRepository1.DeleteUser(id);
            return new OkResult();
        }
    }
}
