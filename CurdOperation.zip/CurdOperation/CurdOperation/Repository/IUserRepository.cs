﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CurdOperation.Model;

namespace CurdOperation.Repository
{
    public interface IUserRepository
    {
        IEnumerable<UserInformation> GetUserInformation();

        UserInformation GetUserByID(int userId);
        UserInformation InsertUser(string userName);

        void UpdateUser(int userId, string userName);

        void DeleteUser(int userId);
    }
}
