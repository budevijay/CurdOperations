﻿using CurdOperation.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CurdOperation.DBContexts;

using System.Linq;

namespace CurdOperation.Repository
{
    internal class UserRepository : IUserRepository
    {
        private readonly UserContext _dbContext;

        public UserRepository(UserContext userContext)
        {
            _dbContext = userContext;
        }
        public void DeleteUser(int userId)
        {
            var userDelete = _dbContext.Users.Find(userId);
            if (userDelete != null)
            {
                _dbContext.Users.Remove(userDelete);
                Save();
            }
        }

        public UserInformation GetUserByID(int userId)
        {
            try
            {
                return _dbContext.Users.Find(userId);
            }
            catch (Exception ex)
            {

                return null;
            }
           
        }

        public IEnumerable<UserInformation> GetUserInformation()
        {
            try
            {
                return (IEnumerable<UserInformation>)_dbContext.Users.ToList();
            }
            catch (Exception ex)
            {

                return null;
            }
        }

        public UserInformation InsertUser(string userName)
        {
            try
            {
                var userData = new UserInformation();
                userData.UserName = userName;
                string names = _dbContext.Users
                            .Where(user => user.UserName == userName)
                            .Select(user => user.UserName).SingleOrDefault();
                if (string.IsNullOrEmpty(names))
                {
                    _dbContext.Add(userData);
                    Save();
                    return userData;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                return null;
            }

        }


        public void UpdateUser(int userId,string userName)
        {
            var userUpdate = _dbContext.Users.Find(userId);
            if(userUpdate !=null)
            {
                userUpdate.UserName = userName;
                _dbContext.Entry<UserInformation>(userUpdate).State = EntityState.Modified;
                Save();
            }
        }

        private void Save()
        {
            _dbContext.SaveChanges();
        }
    }
}
